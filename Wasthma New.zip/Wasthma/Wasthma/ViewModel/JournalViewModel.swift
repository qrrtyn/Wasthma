//
//  JournalViewModel.swift
//  Wasthma
//
//  Created by Arma Qurrota Ayuni on 05/12/22.
//

import Foundation
