////
////  HealthPermissionView.swift
////  Wasthma
////
////  Created by Arma Qurrota Ayuni on 08/12/22.
////
//
//import SwiftUI
//import HealthKit
//
//struct HealthPermissionView: View {
//    @State private var showingAlert = false
//    @State var isReady = false
//    var body: some View {
//        VStack {
//            Spacer()
//            Image("healthapp")
//            Text("Health Kit Synchronised")
//                .font(.title)
//                .fontWeight(.bold)
//                .padding()
//            Text("Our app requires access to healthkit. So that we can integrate with **your activities**, such as activity data, heart rate data, and blood oxygen (when using an Apple Watch), so that we can more **easily provide notification of your asthma condition**. So that\nwe can help to prevent asthma attacks.")
//                .font(.body)
//                .multilineTextAlignment(.center)
//                .padding(.horizontal, 20.0)
//            Spacer()
//            
//            Button("Next") {
//                showingAlert = true
//            }
//            .alert(isPresented: $showingAlert) {
//                Alert(
//                    title: Text("“Wasthma” Would Like to Access Your Healthkit?"),
//                    message: Text("Wasthma using healthkit to know about your activities."),
//                    primaryButton: .destructive(Text("Don't Allow"), action: {
//                        
//                    }),
//                    secondaryButton: .default(Text("Allow"), action: {
//                        Task {
//                            if !HKHealthStore.isHealthDataAvailable() {
//                                return
//                            }
//                            
//                            guard await requestPermission() == true else {
//                                return
//                            }
//                            
//                            isReady = true
//                        }
//                    })
//                )
//            }
//        }
//    }
//}
//
//
//struct HealthPermissionView_Previews: PreviewProvider {
//    static var previews: some View {
//        HealthPermissionView()
//    }
//}
//
