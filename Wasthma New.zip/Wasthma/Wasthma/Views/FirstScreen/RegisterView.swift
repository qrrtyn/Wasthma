////
////  RegisterView.swift
////  Wasthma
////
////  Created by Arma Qurrota Ayuni on 08/12/22.
////
//
//
//import SwiftUI
//
//struct RegisterView: View {
//    @State private var nfirstName: String = ""
//    @State private var nlastName: String = ""
//    @State private var nemail: String = ""
//    @State private var npassword: String = ""
//    @State private var nage: String = ""
//    @State private var nyear: String = ""
//    @State private var selectedIndex = 0
//    private var genderArray = ["Male", "Female"]
//    
//    var body: some View {
//        
//        VStack{
//            VStack(alignment: .leading){
//                Text("What is your name?")
//                    .font(.headline)
//                    .fontWeight(.bold)
//                    
//                TextField("First Name",text: $nfirstName)
//                    .padding()
//                    .border(.black)
//                    .frame(width: 360)
//                TextField("Last Name", text: $nlastName)
//                    .padding()
//                    .border(.black)
//                    .frame(width: 360)
//                TextField("Email", text: $nemail)
//                    .padding()
//                    .border(.black)
//                    .frame(width: 360)
//                TextField("Password", text: $npassword)
//                    .padding()
//                    .border(.black)
//                    .frame(width: 360)
//            }
//            Spacer()
//            VStack(alignment: .leading) {
//                Text("Gender")
//                    .font(.headline)
//                    .fontWeight(.bold)
//                    .padding(.leading)
//                Picker(selection: $selectedIndex, label: EmptyView()) {
//                    ForEach(0 ..< genderArray.count) {
//                        Text(self.genderArray[$0])
//                    }
//                }
//                .pickerStyle(SegmentedPickerStyle())
//                .padding()
//            }
//            Spacer()
//            HStack {
//                Text("Age")
//                    .font(.headline)
//                    .fontWeight(.bold)
//                    .padding(.trailing)
//                TextField("Year", text: $nage)
//                    .padding()
//                    .border(.black)
//                    .frame(width: 290)
//            }
//            Spacer()
//            VStack(alignment: .leading) {
//                Text("How long have you been suffering asthma?")
//                    .font(.headline)
//                    .fontWeight(.bold)
//                 
//                    .padding(.top)
//                TextField("Year", text: $nyear)
//                    .padding()
//                    .border(.black)
//                    .frame(width: 360)
//            }
//            Spacer()
//            Button {
//                
//            } label: {
//                Text("Next")
//                    .frame(width: 350)
//            }
//            .padding()
//            .buttonStyle(.borderedProminent)
//            Spacer()
//        }
//    }
//}
//
//
//struct RegisterView_Previews: PreviewProvider {
//    static var previews: some View {
//        RegisterView()
//    }
//}
