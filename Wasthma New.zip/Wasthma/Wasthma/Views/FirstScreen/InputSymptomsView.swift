//
//  InputSymptomsView.swift
//  Wasthma
//
//  Created by Arma Qurrota Ayuni on 08/12/22.
//

import SwiftUI

struct InputSymptomsView: View {
    @Binding var checkedWheezing: Bool
    @Binding var checkedDB: Bool
    @Binding var checkedAlergies: Bool
    @Binding var checkedFT: Bool
    @State private var nsymptoms: String = ""
    var body: some View {
        VStack(alignment: .leading) {
            VStack(alignment: .leading) {
                Text("My Symptoms")
                    .font(.title2)
                    .fontWeight(.bold)
                    .padding(.bottom)
                Text("Please choose the asthma symptoms that you often experience")
                    .font(.subheadline)
            }
            .padding()
            Spacer()
            
            VStack(alignment:.leading){
                HStack {
                    Image(systemName: checkedWheezing ? "checkmark.square.fill" : "square")
                        .resizable()
                        .foregroundColor(checkedWheezing ? Color(UIColor.systemBlue) : Color.secondary)
                        .frame(width: 30.0, height: 30.0)
                        
                        .onTapGesture {
                            self.checkedWheezing.toggle()
                        }
                    Text("Wheezing")
                    
                }
                
                HStack {
                    Image(systemName: checkedDB ? "checkmark.square.fill" : "square")
                        .resizable()
                        .foregroundColor(checkedDB ? Color(UIColor.systemBlue) : Color.secondary)
                        .frame(width: 30.0, height: 30.0)
                        .padding()
                        .onTapGesture {
                            self.checkedDB.toggle()
                        }
                    Text("Difficulty Breathing")
                }
               
                HStack {
                    Image(systemName: checkedAlergies ? "checkmark.square.fill" : "square")
                        .resizable()
                        .foregroundColor(checkedAlergies ? Color(UIColor.systemBlue) : Color.secondary)
                        .frame(width: 30.0, height: 30.0)
                        .padding()
                        .onTapGesture {
                            self.checkedAlergies.toggle()
                        }
                    Text("Alergies")
                }
                
                HStack {
                    Image(systemName: checkedFT ? "checkmark.square.fill" : "square")
                        .resizable()
                        .foregroundColor(checkedFT ? Color(UIColor.systemBlue) : Color.secondary)
                        .frame(width: 30.0, height: 30.0)
                        .padding()
                        .onTapGesture {
                            self.checkedFT.toggle()
                        }
                    Text("Feeling Tired")
                }
                
            }
            .padding()
            Spacer()
            Text("Add yours")
                .font(.title3)
                .fontWeight(.bold)
                .padding(.top)
                .padding(.leading)
            Spacer()
            HStack{
                TextField("Add your symptoms", text: $nsymptoms)
                    .padding()
                    .border(.black)
                    .frame(width: 280)
                Button {
                    
                } label: {
                    Text("Add +")
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
            VStack() {
                Text("You can set your own symptoms and triggers on profile")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                Button {
                    
                } label: {
                    Text("Next")
                        .frame(width: 350)
                }
                .buttonStyle(.borderedProminent)
                
            }
            .padding()
            Spacer()
        }
    }
}

struct InputSymptomsView_Previews: PreviewProvider {
    struct SymptomsViewHolder: View {
        @State var checkedWheezing = false
        @State var checkedDB = false
        @State var checkedAlergies = false
        @State var checkedFT = false
        var body: some View {
            InputSymptomsView(checkedWheezing: $checkedWheezing, checkedDB: $checkedDB, checkedAlergies: $checkedAlergies, checkedFT: $checkedFT)
        }
    }
    static var previews: some View {
        SymptomsViewHolder()
    }
}
