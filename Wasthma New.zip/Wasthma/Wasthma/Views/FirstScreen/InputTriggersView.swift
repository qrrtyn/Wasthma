//
//  InputTriggersView.swift
//  Wasthma
//
//  Created by Arma Qurrota Ayuni on 08/12/22.
//

import SwiftUI


struct InputTriggersView: View {
    @Binding var checkedPollution: Bool
    @Binding var checkedDust: Bool
    @Binding var checkedFF: Bool
    @Binding var checkedPet: Bool
    @State private var nsymptoms: String = ""
    var body: some View {
        VStack(alignment: .leading) {
            VStack(alignment: .leading) {
                Text("My Triggers")
                    .font(.title2)
                    .fontWeight(.bold)
                    .padding(.bottom)
                Text("Please choose the asthma triggers that you often experience")
                    .font(.subheadline)
            }
            .padding()
            Spacer()
            
            VStack(alignment:.leading){
                HStack {
                    Image(systemName: checkedPollution ? "checkmark.square.fill" : "square")
                        .resizable()
                        .foregroundColor(checkedPollution ? Color(UIColor.systemBlue) : Color.secondary)
                        .frame(width: 30.0, height: 30.0)
                        
                        .onTapGesture {
                            self.checkedPollution.toggle()
                        }
                    Text("Pollution")
                    
                }
                
                HStack {
                    Image(systemName: checkedDust ? "checkmark.square.fill" : "square")
                        .resizable()
                        .foregroundColor(checkedDust ? Color(UIColor.systemBlue) : Color.secondary)
                        .frame(width: 30.0, height: 30.0)
                        .padding()
                        .onTapGesture {
                            self.checkedDust.toggle()
                        }
                    Text("Dust")
                }
               
                HStack {
                    Image(systemName: checkedFF ? "checkmark.square.fill" : "square")
                        .resizable()
                        .foregroundColor(checkedFF ? Color(UIColor.systemBlue) : Color.secondary)
                        .frame(width: 30.0, height: 30.0)
                        .padding()
                        .onTapGesture {
                            self.checkedFF.toggle()
                        }
                    Text("Fatty Food")
                }
                
                HStack {
                    Image(systemName: checkedPet ? "checkmark.square.fill" : "square")
                        .resizable()
                        .foregroundColor(checkedPet ? Color(UIColor.systemBlue) : Color.secondary)
                        .frame(width: 30.0, height: 30.0)
                        .padding()
                        .onTapGesture {
                            self.checkedPet.toggle()
                        }
                    Text("Pet")
                }
                
            }
            .padding()
            Spacer()
            Text("Add yours")
                .font(.title3)
                .fontWeight(.bold)
                .padding(.top)
                .padding(.leading)
            Spacer()
            HStack{
                TextField("Add your symptoms", text: $nsymptoms)
                    .padding()
                    .border(.black)
                    .frame(width: 280)
                Button {
                    
                } label: {
                    Text("Add +")
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
            VStack() {
                Text("You can set your own symptoms and triggers on profile")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                Button {
                    
                } label: {
                    Text("Next")
                        .frame(width: 350)
                }
                .buttonStyle(.borderedProminent)
                
            }
            .padding()
            Spacer()
        }
    }
}

struct InputTriggersView_Previews: PreviewProvider {
    struct TriggersViewHolder: View {
        @State var checkedPollution = false
        @State var checkedDust = false
        @State var checkedFF = false
        @State var checkedPet = false
        var body: some View {
            InputTriggersView(checkedPollution: $checkedPollution, checkedDust: $checkedDust, checkedFF: $checkedFF, checkedPet: $checkedPet)
        }
    }
    
    static var previews: some View {
        TriggersViewHolder()
    }
}

