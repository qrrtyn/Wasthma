//
//  CardView.swift
//  Wasthma
//
//  Created by Arma Qurrota Ayuni on 05/12/22.
//

import Foundation
import SwiftUI

struct CardView: View {
    let journal: JournalEntity


    var body: some View {

        VStack {
            RoundedRectangle(cornerRadius: 20)
                .frame(width: 352, height: 144)
                .foregroundColor(.white)
                .shadow(radius: 5)
                .overlay {
                    HStack (spacing: -10) {
                        VStack(spacing: 10) {
                            Image(journal.feeling )
                                .resizable()
                                .frame(width: 70, height: 70)
                            Text(journal.feeling )
                                .foregroundColor(.blue)
                                .bold()
                        }
                        .padding()

                        VStack(alignment: .leading, spacing: 3) {
                            Text("Sunday, 1 October 2022")
                                .font(.headline)
                            Text(journal.notes )
                            HStack {
                                VStack(alignment: .leading, spacing: 3) {
                                    HStack {
                                        Text("Symptom")
                                            .foregroundColor(.blue)
                                            .bold()

                                    }
                                    HStack {
                                        Text("Trigger")
                                            .foregroundColor(.blue)
                                            .bold()
                                    }
                                    HStack {
                                        Text("Medicine")
                                            .foregroundColor(.blue)
                                            .bold()
                                    }
                                }
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(journal.symptomsName )
                                    Text(journal.triggersName )
                                    Text(journal.medicineName )
                                }
                            }
                        }
                        .padding()
                    }
                }
        }
    }
}
