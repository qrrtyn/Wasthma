////
////  DashboardView.swift
////  Wasthma
////
////  Created by Arma Qurrota Ayuni on 05/12/22.
////
//
//import SwiftUI
//
//
//struct DashboardView: View {
//
//    @State var journals: [JournalEntity] = []
////    @FetchRequest(sortDescriptors: []) var journalss: FetchedResults<Journal>
//    @State var session: String? = nil
//
//    var body: some View {
//        NavigationView {
//            ZStack {
//                Color.gray.opacity(0.1)
//                    .edgesIgnoringSafeArea(.all)
//                LinearGradient(gradient: Gradient(colors: [kGradient1Color, kGradient1Color, kGradient1Color, kGradient2Color]), startPoint: .top, endPoint: .bottom)
//                    .cornerRadius(20)
//                    .frame(height: 229)
//                    .offset(y: -325)
//                VStack {
//                    HStack {
//                        VStack (alignment: .leading){
//                            Text("Hi Charles 👋🏼")
//                                .foregroundColor(.white)
//                                .font(.title)
//                                .fontWeight(.bold)
//                                .padding(.bottom, 3)
//
//                            Text("Take care of your self")
//                                .foregroundColor(.white)
//                                .font(.subheadline)
//
//                        }
//                        Spacer()
//
//                        
//                        NavigationLink(destination: ProfileView(showImagePicker:
//                        false)) {
//                            Image(systemName: "person.circle.fill")
//                                .font(.custom(String(), size: 45))
//                                .foregroundColor(.white)
//                                .padding(.horizontal)
//                        }
//                        
//                    }
//                    .padding(20)
//
//                    HStack {
//                        Spacer()
//                        VStack {
//                            Text (" Air Quality")
//                                .fontWeight(.semibold)
//                            Image(systemName: "lungs")
//                                .resizable()
//                                .scaledToFit()
//                                .frame(width: 85,height:85)
//                            Text ("Moderate")
//                                .fontWeight(.semibold)
//                        }
//                        .padding()
//                        .frame(width: 164, height: 186)
//                        .background(RoundedRectangle(cornerRadius: 10).foregroundColor(.white).shadow(radius: 7, x: 1, y: 1))
//                        Spacer()
//                        VStack {
//                            Text ("Your Step")
//                                .fontWeight(.semibold)
//                            Image("step")
//                                .resizable()
//                                .scaledToFit()
//                                .frame(width: 85,height:85)
//                            Text ("2.212 Steps")
//                                .fontWeight(.semibold)
//                        }
//    //                    .padding()
//                        .frame(width: 164, height: 186)
//                        .background(RoundedRectangle(cornerRadius: 10).foregroundColor(.white).shadow(radius: 7, x: 1, y: 1))
//
//                        Spacer()
//                    }
//
//                    HStack {
//                        Text ("Recent Report")
//                            .font(
//                                .title3
//                                    .weight(.bold)
//                            )
//                        Spacer()
//                        NavigationLink(destination: JournalReport()) {
//                            Text("See All")
//                        }
//                            .foregroundColor(.blue)
//                    }
//                    .padding(25)
//
//                    NojournalView()
//                    ForEach (0..<2) { i in
//                        CardView()
//                    }
//
//                    if let card = self.card {
//                        ForEach (0..<2) { i in
//                            Text("kosong")
//                        CardView(journal: journalss[i])
//                                       }
//                    }else {
//                        Image("no-journal")
//                        Text ("There is no progress report Start your journey first")
//                            .frame(width: 267)
//                            .foregroundColor(.gray)
//                            .font(
//                                .title3
//                                    .weight(.bold)
//                            )
//                            .multilineTextAlignment(.center)
//                    }
//                    
//                    Spacer()
//
//    //                NavigationLink(destination: Q1View()){
//    //                    Text("New Asthma Journal")
//    //                        .fontWeight(.bold)
//    //                        .foregroundColor(.white)
//    //                        .padding()
//    //                        .frame(width: 352, height: 44)
//    //                        .background(RoundedRectangle(cornerRadius: 10).foregroundColor(.blue))
//    //                }
//
//                    NavigationLink {
//        //                tadi ini di command
//                        Q1View(journals: .constant([]) )
//                    } label: {
//                        Text("New Asthma Journal")
//                            .foregroundColor(.white)
//                            .frame(width: 352 ,height: 44)
//                            .background(RoundedRectangle(cornerRadius: 8)
//                                .foregroundColor(kPrimaryColor))
//                            .padding(.bottom)
//                    }
//                    
//                }
//                .padding(.bottom)
//            }
//        
//        }            .navigationBarBackButtonHidden(true)
//
//    }
//}
//
//struct DashboardView_Previews: PreviewProvider {
//    static var previews: some View {
//        DashboardView()
//    }
//}
//
//
//
//struct NojournalView: View {
//    var body: some View {
//        VStack {
//            Image("no-journal")
//            Text ("There is no progress report Start your journal first")
//                .frame(width: 267)
//                .foregroundColor(.gray)
//                .font(
//                    .title3
//                        .weight(.bold)
//                )
//                .multilineTextAlignment(.center)
//        }
//        .padding()
//    }
//}
