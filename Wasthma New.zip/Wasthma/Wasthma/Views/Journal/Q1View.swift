//
//  Q1View.swift
//  Wasthma
//
//  Created by Arma Qurrota Ayuni on 05/12/22.
//

import SwiftUI


struct Q1View: View {
    
//     MARK : Environment Values
//    @StateObject var symptomsModel: SymptomsViewModel = .init()
//    @Environment(\.self) var env
//   
//    @ObservedObject var vm = ProfileViewModel()
//
//    
//    @ObservedObject var journals: [Journal]
    @Binding var journals: [JournalEn]
    @State var selectedFeeling: String = ""
    @State var namePic: String = ""
    let pics = ["Good", "Neutral", "Confused", "Sad"]

    @State private var isPresented = false
    
    let adaptiveCollumns = [
        GridItem(.adaptive(minimum: 170))
    ]
    @Environment(\.dismiss) private var dismiss
//    @State var currentIndex: Int = 0
    var body: some View {
        VStack{

            Image("Q1")
                .padding(.top)
            
            Text("How are you feeling today?")
                .padding(30)
                .font(.title2.bold())
                .foregroundColor(kSecondaryColor)
            
            LazyVGrid(columns: adaptiveCollumns, spacing: 30) {
                ForEach(pics, id: \.self) { name in
                    CardFeeling(isSelected: namePic == name, size: 150, namePic: name)
                        .onTapGesture {
                            withAnimation(.default) {
                                namePic = name
                                selectedFeeling = name
//                                symptomsModel.selectedFeeling = name
                            }
                        }
                }
            }
            .padding(20)
            
            Spacer()
            
            NavigationLink {
//                tadi ini di command
                Q2View(journals: $journals, selectedFeeling: selectedFeeling)
            } label: {
                Text("Next")
                    .foregroundColor(.white)
                    .frame(width: 352 ,height: 44)
                    .background(RoundedRectangle(cornerRadius: 8)
                        .foregroundColor(kPrimaryColor))
                    .padding(.bottom)
            }
        }
        
//        .toolbar{
//            ToolbarItem(placement: .navigationBarLeading) {
//                Button {
//                    selectedFeeling == "" ? dismiss() : isPresented.toggle()
//                } label: {
//                    HStack {
//                        Image(systemName: "chevron.left")
//                        Text("Back")
//                        Spacer()
//                    }
////                    .foregroundColor(Color.black)
//                }
//            }
//        }
        .navigationTitle("Journal")
        .navigationBarTitleDisplayMode(.inline)
//        .navigationBarBackButtonHidden(true)
        .alert(isPresented: $isPresented) {
            getAlert()
        }
    }
    
    func getAlert() -> Alert {
        return Alert(
            title: Text("Warning"),
            message: Text("If you out, your data will be lost"),
            primaryButton: .destructive(Text("Delete"), action: {
                dismiss()
            }),
            secondaryButton: .cancel())
    }
}

struct Q1View_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            Q1View(journals: .constant([]))
        }



    }
}

struct CardFeeling: View {
    
    var isSelected: Bool
    let size: CGFloat
    let namePic: String
    
    var body: some View {
        VStack {
            RoundedRectangle(cornerRadius: 20)
                .frame(width: size,height: size)
                .shadow(radius: 10)
                .foregroundColor(isSelected ? kPrimaryColor : .white)
                .overlay(
                    VStack {
                        Image("\(namePic)")
                            .resizable()
                            .frame(width: 70, height: 70, alignment: .center)
                            .clipShape(Circle())
                            .shadow(color: Color.white,radius: 25)

                        Text(namePic)
                            .fontWeight(.semibold)
                            .foregroundColor(isSelected ? .white : .blue)
                    }
                
                )
        }
    }
}

struct CardFeelingPic: View {
    
    let name: String
    let widthPic: CGFloat
    let heightPic: CGFloat
    
    var body: some View {
        Image(name)
            .resizable()
            .scaledToFit()
            .frame(width: widthPic, height: heightPic)
            .font(.largeTitle)
    }
}
