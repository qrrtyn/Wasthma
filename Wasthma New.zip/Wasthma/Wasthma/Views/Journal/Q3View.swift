//
//  Q3View.swift
//  Wasthma
//
//  Created by Arma Qurrota Ayuni on 05/12/22.
//

import SwiftUI
import CoreData

struct Q3View: View {
    
//    @ObservedObject var symptomsModel: SymptomsViewModel
    
    
    @Environment(\.managedObjectContext) var moc
    @Binding var journals: [JournalEn]
//    @FetchRequest(sortDescriptors: []) var journalss: FetchedResults<JournalEn>
    
    var selectedFeeling: String //Passing Feeling
    var selectedSymptom: String
    var selectedTrigger: String
    var selectedMedicine: String
    var startAttack = Date()
    var endAttack = Date()
    
    @State var textNotes: String = ""
    @State var isAlertPresent: Bool = false
    
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack {
            Image("Q3")
                .padding(.vertical)
//            Spacer()
            // Input
            
            TextEditor(text: $textNotes)
                    .frame(width: 340, height: 443)
                    .cornerRadius(10)
                    .shadow(radius: 5)
                   
           
//                .shadow(color: .gray, radius: 5, x: 1, y: 2)
            //Button
            Spacer()
//            Button {
//                FinishJournalView()
////                saveJournal(symptom: selectedFeeling, trigger: "", medicine: "", feeling: "", startAttack: Date(), endAttack: Date(), notes: textNotes)
//////                journals.append(newJournal)
//////                print(journals)
////                isAlertPresent.toggle()
//            } label: {
//                Text("Save")
//                    .foregroundColor(.white)
//                    .frame(width: 352 ,height: 44)
//                    .background(RoundedRectangle(cornerRadius: 8).foregroundColor(.blue))
//                    .padding()
//            }
            
//            NavigationLink {
//              FinishJournalView()
//            }
//        label: {
//            Text("NEXT")
//                .foregroundColor(.white)
//                .frame(width: 352 ,height: 44)
//                .background(RoundedRectangle(cornerRadius: 8).foregroundColor(.blue))
//                .padding()
//        }

        }
//        .toolbar{
//            ToolbarItem(placement: .navigationBarLeading) {
//                Button {
//                    dismiss()
//                } label: {
//                    HStack {
//                        Image(systemName: "chevron.left")
//                        Text("Back")
//                        Spacer()
//                    }
//                }
//            }
//        }
        .navigationTitle("Journal")
        .navigationBarTitleDisplayMode(.inline)
//        .navigationBarBackButtonHidden(true)
//        .navigationDestination(isPresented: $isAlertPresent) {

    }
    
    func saveJournal(symptom: String, trigger: String, medicine: String, feeling: String, startAttack: Date, endAttack: Date, notes: String) {
        
//        let journal = JournalEn(context: moc)
//        journal.symptom = symptom
//        journal.trigger = trigger
//        journal.medicine = medicine
//        journal.feeling = feeling
//        journal.startAttack = startAttack
//        journal.endAttack = endAttack
//        journal.notes = notes
//        try? moc.save()
        
    }
}

struct Q3Views_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            Q3View(journals: .constant([]), selectedFeeling: "", selectedSymptom: "", selectedTrigger: "", selectedMedicine: "", startAttack: Date(), endAttack: Date())
        }
    }
}

//Display
//            Text(textNotes)
//                .foregroundColor(.yellow)
//                .lineLimit(nil)
//                .padding(5)
//                .frame(width: UIScreen.main.bounds.width * 0.8, height: 200, alignment: .topLeading)
//                .overlay(
//                    RoundedRectangle(cornerRadius: 10)
//                        .stroke(Color.green, lineWidth: 5)
//                )
