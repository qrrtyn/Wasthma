////
////  FinishJournalView.swift
////  Wasthma
////
////  Created by Arma Qurrota Ayuni on 05/12/22.
////
//
//import SwiftUI
//
//struct FinishJournalView: View {
//    var body: some View {
//        
//        VStack{
//            Image ("Good")
//                .resizable()
//                .frame(width: 200 , height: 200, alignment: .center)
//                .padding(.bottom)
//            Text("Congratulations!")
//                .font(.title2)
//                .foregroundColor(.blue)
//                .padding(.vertical)
//            
//            Text ("You add new journal")
//                .foregroundColor(.gray)
//                .multilineTextAlignment(.center)
//                .padding(.bottom)
//       
//            NavigationLink {
//              DashboardView()
//            }
//        label: {
//            Text("Go to main")
//                .foregroundColor(.white)
//                .frame(width: 352 ,height: 44)
//                .background(RoundedRectangle(cornerRadius: 8).foregroundColor(.blue))
//                .padding()
//        }
//
//            .padding(.top)
//            
//            
//        }
//        .navigationBarBackButtonHidden()
//    }
//}
//
//
//struct GoToButtonContent: View {
//    var body: some View {
//        Text("Go To Journal Progress")
//            .fontWeight(.semibold)
//            .frame(width: 352, height: 50)
//            .foregroundColor(.white)
//            .background(kPrimaryColor)
//            .cornerRadius(8)
//    }
//}
//struct FinishJournalView_Previews: PreviewProvider {
//    static var previews: some View {
//        FinishJournalView()
//    }
//}
