////
////  CongratsView.swift
////  Wasthma
////
////  Created by Arma Qurrota Ayuni on 05/12/22.
////
//
//import SwiftUI
//
//
//struct CongratsView: View {
//    var body: some View {
//        VStack {
//            Spacer()
//            Image("Congrats")
//                .resizable()
//                .frame(width: 252, height: 191)
//            
//            Text("Congratulations!")
//                .foregroundColor(.blue)
//                .font(.title.bold())
//            
//            Text("You add new journal")
//            Spacer()
//            
//            Button {
//                //DashboardView()
//            } label: {
//                Text("Finish")
//                    .foregroundColor(.white)
//                    .frame(width: 352 ,height: 44)
//                    .background(RoundedRectangle(cornerRadius: 8).foregroundColor(.blue))
//                    .padding()
//            }
//        }
//        .navigationTitle("Journal")
//        .navigationBarTitleDisplayMode(.inline)
//        .navigationBarBackButtonHidden(true)
//    }
//}
//
//struct CongratsView_Previews: PreviewProvider {
//    static var previews: some View {
//        NavigationView {
//            CongratsView()
//        }
//    }
//}
//
