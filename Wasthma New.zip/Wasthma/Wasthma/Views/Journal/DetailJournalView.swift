//
//  DetailJournalView.swift
//  Wasthma
//
//  Created by Arma Qurrota Ayuni on 05/12/22.
//

import SwiftUI

struct DetailJournalView: View {
    @Binding var journals: [JournalEn]
    @State var selectedFeeling: String //Passing Feeling
    @FetchRequest(sortDescriptors: []) var journalss: FetchedResults<JournalEn>
    var body: some View {
   
        
        VStack {

            Text("Symptoms")
                .font(.title3)
                .fontWeight(.semibold)
                .foregroundColor(kSecondaryColor)
                .multilineTextAlignment(.trailing)

//            VStack {
//                RoundedRectangle(cornerRadius: 20)
//                    .frame(width: 364,height: 192)
//                    .shadow(radius: 10)
//                    .foregroundColor(isSelected ? kPrimaryColor : .white)
//                    .overlay(
//                        VStack {
//                            Image("\(vm.namePic.)")
//                                .resizable()
//                                .frame(width: 70, height: 70, alignment: .center)
//                                .clipShape(Circle())
//                                .shadow(color: Color.white,radius: 25)
//    //                        CardFeelingPic(name: namePic, widthPic: 70, heightPic: 98)
//
//                            Text(namePic)
//                                .fontWeight(.semibold)
//                                .foregroundColor(isSelected ? .white : .blue)
//                        }
//
//                    )
//            }
//
//            NavigationLink {
//                FinishJournalView()
//            } label: {
//                Text("Next")
//                    .foregroundColor(.white)
//                    .frame(width: 352 ,height: 44)
//                    .background(RoundedRectangle(cornerRadius: 8).foregroundColor(kPrimaryColor))
//                    .padding()
//        }

        }
        .navigationTitle("Detail Journal")
        .navigationBarTitleDisplayMode(.inline)
        
        
        
        
    }
}

struct DetailJournalView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
           DetailJournalView(journals: .constant([]), selectedFeeling: "")
        }
    }
}
