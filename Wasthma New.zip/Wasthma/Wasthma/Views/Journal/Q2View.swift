//
//  Q2View.swift
//  Wasthma
//
//  Created by Arma Qurrota Ayuni on 05/12/22.
//

import SwiftUI

struct Q2View: View {
    
    @Binding var journals: [JournalEn]
    var selectedFeeling: String
    
    @State private var currentDate = Date()
    @State private var selectedSymptom: String = ""
    @State private var selectedTrigger: String = ""
    @State private var selectedMedicine: String = ""
    @State private var startAttack = Date()
    @State private var endAttack = Date()
    
    @State var dattaArray : [String] = []
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack {
            Image("Q2")
                .padding(.top)
            ScrollView {
                HStack {
                    Text("Asthma Attacks Start")
                        .font(.headline.bold())
                    
                    Spacer()
                    DatePicker("", selection: $startAttack, displayedComponents: .hourAndMinute)
                        .labelsHidden()
                }
                
                HStack {
                    Text("Asthma Attacks End")
                        .font(.headline.bold())
                    Spacer()
                    DatePicker("", selection: $endAttack, displayedComponents: .hourAndMinute)
                        .labelsHidden()
                }
                
                VStack(alignment: .leading) {
                    Text("Symtomps")
                        .font(.headline.bold())
//                    ini
                    SymptomsView(selectedSymptoms: $selectedSymptom)
                        .padding(.horizontal)
                }
                
                VStack(alignment: .leading) {
                    Text("Causes & Trigger")
                        .font(.headline.bold())
                    
                    TriggerView(selectedTriggers: $selectedTrigger)
                        .padding(.horizontal)
                }
                
                VStack(alignment: .leading) {
                    Text("Medicine")
                        .font(.headline.bold())
//                    ini cmd
                    MedicineView(selectedMedicine: $selectedMedicine)
                        .padding(.horizontal)
                }
                
                Spacer()
                
            }
            .padding(20)
            
            NavigationLink {
                Q3View(journals: $journals, selectedFeeling: selectedFeeling, selectedSymptom: selectedSymptom, selectedTrigger: selectedTrigger, selectedMedicine: selectedMedicine, startAttack: startAttack, endAttack: endAttack)
            }
        label: {
            Text("NEXT")
                .foregroundColor(.white)
                .frame(width: 352 ,height: 44)
                .background(RoundedRectangle(cornerRadius: 8).foregroundColor(.blue))
                .padding()
        }
        }
        .toolbar{
            ToolbarItem(placement: .navigationBarLeading) {
                Button {
                    dismiss()
                } label: {
                    Text("Next")
                        .foregroundColor(.white)
                        .frame(width: 352 ,height: 44)
                        .background(RoundedRectangle(cornerRadius: 8).foregroundColor(kPrimaryColor))
                        .padding()
                }
            }
        }//
//        .toolbar{
//            ToolbarItem(placement: .navigationBarLeading) {
//                Button {
//                    dismiss()
//                } label: {
//                    HStack {
//                        Image(systemName: "chevron.left")
//                        Text("Back")
//                        Spacer()
//                    }
//                }
//            }
//        }
        .navigationTitle("Journal")
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(true)
        .scrollIndicators(.hidden)
    }
}
//    
//struct Q2View_Previews: PreviewProvider {
//    static var previews: some View {
//        NavigationView {
//            //Q3View(journals: .constant([]), selectedFeeling: "")
//        }
//    }
//}
    
    //View Symptom List
struct SymptomsView: View {

    @State private var symptoms = [
        Symptoms(symptomsName: "Wheezing", symptomsIsComplete: false),
        Symptoms(symptomsName: "Difficulty Breathing", symptomsIsComplete: false),
        Symptoms(symptomsName: "Allergies", symptomsIsComplete: false),
        Symptoms(symptomsName: "Feelling Tired", symptomsIsComplete: false)
    ]

    @Binding var selectedSymptoms: String

    var body: some View {
//        Text("3")
//        ini
        ForEach(symptoms) { symptom in
            VStack {
                HStack {
                    Image(systemName:
                            symptom.symptomsName == selectedSymptoms ? "checkmark.circle.fill" : "circle")
                    .foregroundColor( symptom.symptomsName == selectedSymptoms ? kPrimaryColor : .black)
                    Text(symptom.symptomsName)


                    Spacer()
                }
                .padding(4)
                .onTapGesture {
                    selectedSymptoms = symptom.symptomsName
                }
            }
        }
    }
    //.navigationTitle("Journal")
    //.navigationBarTitleDisplayMode(.inline)
    //.navigationBarBackButtonHidden(true)
}


struct MedicineView: View {
//    ini
    @State private var medicine = [
        Medicine(medicineName: "Drug", medicineIsComplete: false),
        Medicine(medicineName: "Nebulizer", medicineIsComplete: false),
        Medicine(medicineName: "Inhaler", medicineIsComplete: false)
    ]
    @Binding var selectedMedicine: String
    
    var body: some View {
//        Text("1")
//        ini
        ForEach(medicine) { medicine in
            HStack {
                Image(systemName:
                        medicine.medicineName == selectedMedicine ? "checkmark.circle.fill": "circle")
                .foregroundColor(medicine.medicineName == selectedMedicine ? kPrimaryColor : .black)
                Text(medicine.medicineName)
                Spacer()
            }
            .padding(4)
            .onTapGesture {
                selectedMedicine = medicine.medicineName
            }
        }.listStyle(.plain)
    }
}


//View Trigger List
struct TriggerView: View {
//    ini
    private let triggers = [
        Triggers(triggersName: "Pollution", triggersIsComplete: false),
        Triggers(triggersName: "Dust", triggersIsComplete: false),
        Triggers(triggersName: "Pet", triggersIsComplete: false),
        Triggers(triggersName: "Fatty Food", triggersIsComplete: false)
    ]
    @Binding var selectedTriggers: String
    
    var body: some View {
//        Text("3")
//        ini
        ForEach(triggers) { trigger in
            HStack {
                Image(systemName:
                        trigger.triggersName == selectedTriggers ? "checkmark.circle.fill": "circle")
                .foregroundColor(trigger.triggersName == selectedTriggers ? kPrimaryColor : .black)
//                        trigger.triggersName == selectedTriggers ? "checkmark.circle" : "square")
                Text(trigger.triggersName)

                Spacer()
            }
            .padding(2)
            .onTapGesture {
                selectedTriggers = trigger.triggersName
            }
        }
        .listStyle(.plain)
    }
}


//Symptoms Class
struct Symptoms: Identifiable {
let id = UUID()
let symptomsName: String
var symptomsIsComplete: Bool
}

//Triggers Class
struct Triggers: Identifiable {
let id = UUID()
let triggersName: String
var triggersIsComplete: Bool
}


//Medicine Class
struct Medicine: Identifiable {
let id = UUID()
let medicineName: String
var medicineIsComplete: Bool
}
