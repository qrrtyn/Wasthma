//
//  EditTriggersView.swift
//  Wasthma
//
//  Created by Arma Qurrota Ayuni on 05/12/22.
//

import SwiftUI


struct EditTriggesView: View {

    @State var textFieldText: String = ""
    @State var triggersArray  = ["Pollution","Dust","Pet", "Fatty Food"]
//    @Binding var triggersList : [Journal]
    var body: some View {
       
            VStack{
                HStack{
                    TextField("Add your triggers", text: $textFieldText)
                        .padding(.horizontal)
                    Button(action: {
                        if textIsAppropriate(){
                            saveText()
                        }
                    }, label: {
                        Text("Add +")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(width: 80, height: 67)
                            .background(textIsAppropriate() ? kPrimaryColor : Color.gray)
                            .cornerRadius(10)
                    })
    //                .padding(.horizontal, 4)
                    .disabled(!textIsAppropriate())
                    
                }
                .padding(.horizontal)
                .background(Color.white)
                .frame(maxWidth: .infinity)
                .overlay(RoundedRectangle(cornerRadius: 10)
                    .stroke(kPrimaryColor)
                    .padding(.horizontal))
                
                
                Spacer(minLength: 5)
                
                List{
                    ForEach(triggersArray, id:\.self) { data in
                     TriggersCard(name: data)
                        
                        .listRowSeparator(.hidden)
                    }
                    .onDelete(perform: delete)
                    
//                    ForEach(vm.savedEntities) {entity in
//                        Text(entity.name ?? "No Name")
//                    }
//                    .onDelete(perform: delete)
                }
                
                .listStyle(.plain)
                
                
                Spacer()
                Text("Swipe left to sort your symptom")
                    .font(.footnote)
                    .foregroundColor(.gray)
                
                
//                
//                Button(action:{
//                    guard !textFieldText.isEmpty else { return }
//                    addItem(array: textFieldText)
//                    textFieldText = ""
//                    
//                }, label: {
//                    Text("Save")
//                        .fontWeight(.semibold)
//                        .frame(width: 352, height: 50)
//                        .foregroundColor(.white)
//                        .background(kPrimaryColor)
//                        .cornerRadius(8)
//                })
              
                
                .navigationTitle("My Triggers")
                .navigationBarTitleDisplayMode(.inline)
                
                
                
            }
    }
    func delete(indexSet: IndexSet){
        triggersArray.remove(atOffsets: indexSet)
        saveText()
    }
    
    func textIsAppropriate() -> Bool{
        if textFieldText.count >= 2{
            return true
        }
        return false
    }
    
    func saveText(){
        triggersArray.append(textFieldText )
        textFieldText = ""
    }
}

struct TriggersCard: View{
    var name: String
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10, style: .circular)
                .fill(.white)
                .frame(height: 50)
                .shadow(radius: 2)
            
            HStack {
                VStack(alignment: .leading){
                    Text(name)
                        .font(.body)
                        .fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 20)
                
            }
        }
    }
}

struct EditTriggesView_Previews: PreviewProvider {
    static var previews: some View {
        EditTriggesView()
    }
}
