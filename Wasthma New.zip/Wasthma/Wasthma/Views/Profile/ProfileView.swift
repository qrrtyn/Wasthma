//
//  ProfileView.swift
//  Wasthma
//
//  Created by Arma Qurrota Ayuni on 05/12/22.
//

import SwiftUI


struct ProfileView: View {
    
    @State  var showSheet: Bool = false
    @State  var showImagePicker: Bool
    @State  var sourceType: UIImagePickerController.SourceType = .camera
    @State  var image: UIImage?
//    @Binding var journals: [Journal]
    var body: some View {
        
     
            VStack{
                VStack{
                Button(action: {
                    self.showSheet = true
                }, label: {
                    if let image = self.image {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 120, height: 120)
                            .cornerRadius(80)
                    }else {
                        Image(systemName: "person.circle.fill")
                            .resizable()
                            .frame(width: 100, height: 100, alignment: .center)
                            .foregroundColor(.gray)
                            .clipShape(Circle())
                    }
                })
                .actionSheet(isPresented: $showSheet){
                    ActionSheet(title: Text("Choose Your Profile Picture"), buttons:
                                    [.default(Text("Photo Library")){
                        self.showImagePicker = true
                        self.sourceType = .photoLibrary
                            
                    },
                                     
                                     .default(Text("Camera")) {
                                         self.showImagePicker = true
                                         self.sourceType = .camera
                                     },
                                     .cancel()
                                    ])
                }
                .edgesIgnoringSafeArea(.all)
            }
                .padding(.top)
                
//                Spacer(minLength: 15)
                
                ZStack {
                    RoundedRectangle(cornerRadius: 10, style: .circular)
                        .fill(.white)
                        .frame(height: 69)
                        .shadow(radius: 2)
                        .padding(.horizontal, 20)
                    
                        
                        VStack(alignment: .leading){
                            Text("Boo Seung Kwan")
                                .font(.body)
                                .fontWeight(.semibold)
                               
                            Text("boongseung@icloud.com")
                                .font(.footnote)
                                .foregroundColor(.gray)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 40)
                        

                }
                
                ZStack {
                    RoundedRectangle(cornerRadius: 10, style: .circular)
                        .fill(.white)
                        .frame(height: 50)
                        .shadow(radius: 2)
                        .padding(.horizontal, 20)
                    
                    HStack {
                        VStack(alignment: .leading){
                            Text("My Symptoms")
                                .font(.body)
                                .fontWeight(.semibold)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 40)
                        NavigationLink(destination: EditSymptomsView()) {
                            Image(systemName: "chevron.right")
                                .font(.footnote)
                                .foregroundColor(.gray)
                                .padding(.horizontal, 40)
                        }
                        
                    }
                }
                
                ZStack {
                    RoundedRectangle(cornerRadius: 10, style: .circular)
                        .fill(.white)
                        .frame(height: 50)
                        .shadow(radius: 2)
                        .padding(.horizontal, 20)
                    
                    HStack {
                        VStack(alignment: .leading){
                            Text("My Triggers")
                                .font(.body)
                                .fontWeight(.semibold)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 40)
                        
                        NavigationLink(destination: EditTriggesView()) {
                            Image(systemName: "chevron.right")
                                .font(.footnote)
                                .foregroundColor(.gray)
                                .padding(.horizontal, 40)
                        }
                       
                    }
                }
                ZStack {
                    RoundedRectangle(cornerRadius: 10, style: .circular)
                        .fill(.white)
                        .frame(height: 50)
                        .shadow(radius: 2)
                        .padding(.horizontal, 20)
                    
                    HStack {
                        VStack(alignment: .leading){
                            Text("Notification")
                                .font(.body)
                                .fontWeight(.semibold)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 40)
                        
                        NavigationLink(destination: EditNotificationView()) {
                            Image(systemName: "chevron.right")
                                .font(.footnote)
                                .foregroundColor(.gray)
                                .padding(.horizontal, 40)
                        }
                    }
                }
                Text ("Customize how you receive update about Air Quality, Weather and Your Asthma Attack")
                    .font(.footnote)
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                    .padding()
                
                Spacer()
                
                
                
            }
            .navigationTitle("Profile")
            .navigationBarTitleDisplayMode(.inline)
            
        
     
  
        .sheet(isPresented: $showImagePicker){
            ImagePicker(image: self.$image, isShown: self.$showImagePicker  , sourceType: self.sourceType)
                
            
        }
    }
}


struct ProfileCard1: View{
    var name: String
    let image: String
    var link: String
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10, style: .circular)
                .fill(.white)
                .frame(height: 50)
                .shadow(radius: 2)
                .padding(.horizontal, 20)
            
            HStack {
                VStack(alignment: .leading){
                    Text(name)
                        .font(.body)
                        .fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 40)
                
                    Image(systemName: image)
                        .font(.footnote)
                        .foregroundColor(.gray)
                        .padding(.horizontal, 40)
                
            }
        }
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
       
        ProfileView( showImagePicker: false)

    }
}
