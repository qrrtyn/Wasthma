//
//  EditSymptomsView.swift
//  Wasthma
//
//  Created by Arma Qurrota Ayuni on 05/12/22.
//

import SwiftUI


struct EditSymptomsView: View {

    @State var textFieldText: String = ""
//    @State var SymptomsCard : String
  @State var symptomsArray = ["Wheezing","Dificulty Breathing","Allergies","Feeling Tired"]
    
    var body: some View {
        
        
        VStack{
            
            HStack{
                TextField("Add your symptoms", text: $textFieldText)
                    .padding(.horizontal)
                Button(action: {
                    if textIsAppropriate(){
                        saveText()
                    }
                }, label: {
                    Text("Add +")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(width: 80, height: 67)
                        .background(textIsAppropriate() ? kPrimaryColor : Color.gray)
                        .cornerRadius(10)
                })
                
                .disabled(!textIsAppropriate())
                
            }
            .padding(.horizontal)
            .background(Color.white)
            .frame(maxWidth: .infinity)
            .overlay(RoundedRectangle(cornerRadius: 10)
                .stroke(kPrimaryColor)
                .padding(.horizontal))
            
            Spacer(minLength: 5)
            
            List{
                ForEach(symptomsArray, id:\.self) { name in
                    SymptomsCard(name: name)
                    
                    
                        .listRowSeparator(.hidden)
                }
                .onDelete(perform: delete)
                
            }
            .listStyle(.plain)
            
            
            Spacer()
            Text("Swipe left to sort your symptom")
                .font(.footnote)
                .foregroundColor(.gray)
            
//            Button(action:{
//                guard !textFieldText.isEmpty else { return }
//                vm.addItem(array: textFieldText)
//                textFieldText = ""
//
//            }, label: {
//                Text("Save")
//                    .fontWeight(.semibold)
//                    .frame(width: 352, height: 50)
//                    .foregroundColor(.white)
//                    .background(kPrimaryColor)
//                    .cornerRadius(8)
//            })
            
           Button {
             
            } label: {
                Text("Next")
                    .foregroundColor(.white)
                    .frame(width: 352 ,height: 44)
                    .background(RoundedRectangle(cornerRadius: 8)
                        .foregroundColor(kPrimaryColor))
                    .padding(.bottom)
                
            }
            
        }
        .navigationTitle("My Symptoms")
        .navigationBarTitleDisplayMode(.inline)
        
       
    }
    func delete(indexSet: IndexSet){
     symptomsArray.remove(atOffsets: indexSet)
        saveText()
    }
    
    func textIsAppropriate() -> Bool{
        if textFieldText.count >= 2{
            return true
        }
        return false
    }
    
    func saveText(){
        symptomsArray.append(textFieldText )
        textFieldText = ""
    }
}

struct SymptomsCard: View{
    var name: String
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10, style: .circular)
                .fill(.white)
                .frame(height: 50)
                .shadow(radius: 2)
            
            HStack {
                VStack(alignment: .leading){
                    Text(name)
                        .font(.body)
                        .fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 20)
                
            }
        }
    }
}
struct EditSymptomsView_Previews: PreviewProvider {
    static var previews: some View {
        EditSymptomsView()
    }
}
