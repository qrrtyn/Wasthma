//
//  EditNotificationView.swift
//  Wasthma
//
//  Created by Arma Qurrota Ayuni on 05/12/22.
//

import SwiftUI


struct EditNotificationView: View {
    @State private var isAirQualityActive = false
    @State private var isWeatherActive = false
    @State private var isAsthmaActive = false
    @State var notifArray: [String] = ["Air Quality", "Weather", "Asthma Attacks"]
    var body: some View {
        
           
        VStack {
                
                List{
                    Toggle("Air Quality", isOn: $isAirQualityActive)
                    Toggle("Weather", isOn: $isWeatherActive)
                    Toggle("Asthma Attacks", isOn: $isAsthmaActive)
                }
                .padding()
                .scrollDisabled(true)
              
                
                
                Text("Customize how you receive update about Air Polution, \nWether and Your Asthma Attack")
                    .font(.footnote)
                    .foregroundColor(.gray)
                    .padding(.horizontal)
                    .multilineTextAlignment(.center)

                Spacer(minLength: 515)
        
            }
            .navigationTitle("Notification")
            .navigationBarTitleDisplayMode(.inline)
        .background(.white)
        .listStyle(.plain)
    }
      
}

struct EditNotificationView_Previews: PreviewProvider {
    static var previews: some View {
        EditNotificationView()
    }
}
