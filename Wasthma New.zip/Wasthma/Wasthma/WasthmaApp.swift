//
//  WasthmaApp.swift
//  Wasthma
//
//  Created by Arma Qurrota Ayuni on 05/12/22.
//

import SwiftUI

@main
struct WasthmaApp: App {
    let persistenceController = DataController()

    var body: some Scene {
        WindowGroup {
            ContentView()
       
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
