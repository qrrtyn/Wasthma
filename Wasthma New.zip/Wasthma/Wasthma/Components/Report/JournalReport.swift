//
//  JournalReport.swift
//  Wasthma
//
//  Created by Arma Qurrota Ayuni on 05/12/22.
//

import SwiftUI

struct JournalReport: View {
    @State var button: Bool = false
    var body: some View {
        VStack {
            Spacer()
            HStack{
                ZStack{
                    RoundedRectangle(cornerRadius: 20)
                        .frame(width: 195.0, height: 110.0)
                        .foregroundColor(.white)
                        .shadow(radius: 10)
                    VStack{
                        Text("Top Symptoms")
                            .font(.subheadline)
                            .bold()
                            .padding()
                        Text("Result")
                            .font(.subheadline)
                            .padding()
                    }
                }
                
                ZStack{
                    RoundedRectangle(cornerRadius: 20)
                        .frame(width: 195.0, height: 110.0)
                        .foregroundColor(.white)
                        .shadow(radius: 10)
                    VStack{
                        Text("Top Triggers")
                            .font(.subheadline)
                            .bold()
                            .padding()
                        Text("Result")
                            .font(.subheadline)
                            .padding()
                    }
                }
                
            }
            .padding()
            HStack{
                ZStack{
                    RoundedRectangle(cornerRadius: 20)
                        .frame(width: 190.0, height: 110.0)
                        .foregroundColor(.white)
                        .shadow(radius: 10)
                    VStack{
                        Text("Top Medicine")
                            .font(.subheadline)
                            .bold()
                            .padding()
                        Text("Result")
                            .font(.subheadline)
                            .padding()
                    }
                }
                
                ZStack{
                    RoundedRectangle(cornerRadius: 20)
                        .frame(width: 190.0, height: 110.0)
                        .foregroundColor(.white)
                        .shadow(radius: 10)
                    VStack{
                        Text("Total Asthma Attacks")
                            .font(.subheadline)
                            .bold()
                            .padding()
                        Text("Result")
                            .font(.subheadline)
                            .padding()
                    }
                }
                
            }
            Spacer()
            HStack {
                Button ("Alltime") {
                    
                }
                .padding()
                .buttonStyle(.borderedProminent)
                
                Button ("Last Week") {
                    
                }
                
                .buttonStyle(.borderedProminent)
                Button ("Last Month") {
                    
                }
                .padding()
                .buttonStyle(.borderedProminent)
            }
            .padding()
            VStack{
                ZStack{
                    RoundedRectangle(cornerRadius: 10)
                        .frame(width: 350, height: 130)
                        .foregroundColor(.white)
                        .shadow(radius: 10)
                    HStack{
                        Image("Good")
                            .resizable()
                            .frame(width: 90, height: 90)
                        VStack(alignment: .leading){
                            Text("Sunday, 1 October 2022")
                                .font(.headline)
                                .padding(.bottom, 1.0)
                            HStack {
                                VStack(alignment: .leading) {
                                    Text("Trigger")
                                        .foregroundColor(.blue)
                                        .bold()
                                        .padding(.trailing)
                                    Text("Symptom")
                                        .foregroundColor(.blue)
                                        .bold()
                                        .padding(.trailing)
                                    Text("Handling")
                                        .foregroundColor(.blue)
                                        .bold()
                                        .padding(.trailing)
                                }
                                VStack(alignment: .leading) {
                                    Text("Dust, Pollution")
                                        .font(.subheadline)
                                    Text("Wheezing")
                                        .font(.subheadline)
                                    Text("Inhaler")
                                        .font(.subheadline)
                                }
                            }
                        }
                    }
                }
                .padding()
                ZStack{
                    RoundedRectangle(cornerRadius: 10)
                        .frame(width: 350, height: 130)
                        .foregroundColor(.white)
                        .shadow(radius: 10)
                    HStack{
                        Image("Good")
                            .resizable()
                            .frame(width: 90, height: 90)
                        VStack(alignment: .leading){
                            Text("Sunday, 1 October 2022")
                                .font(.headline)
                                .padding(.bottom, 1.0)
                            HStack {
                                VStack(alignment: .leading) {
                                    Text("Trigger")
                                        .foregroundColor(.blue)
                                        .bold()
                                        .padding(.trailing)
                                    Text("Symptom")
                                        .foregroundColor(.blue)
                                        .bold()
                                        .padding(.trailing)
                                    Text("Handling")
                                        .foregroundColor(.blue)
                                        .bold()
                                        .padding(.trailing)
                                }
                                VStack(alignment: .leading) {
                                    Text("Dust, Pollution")
                                        .font(.subheadline)
                                    Text("Wheezing")
                                        .font(.subheadline)
                                    Text("Inhaler")
                                        .font(.subheadline)
                                }
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle("Journal Report")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct JournalReport_Previews: PreviewProvider {
    static var previews: some View {
        JournalReport()
    }
}
