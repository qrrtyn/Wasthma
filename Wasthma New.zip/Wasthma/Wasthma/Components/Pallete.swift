//
//  Pallete.swift
//  Wasthma
//
//  Created by Arma Qurrota Ayuni on 05/12/22.
//

import Foundation
import SwiftUI

let kPrimaryColor = Color(red: 5/255, green: 114/255, blue: 216/255)
let kSecondaryColor = Color(red: 0/255, green: 38/255, blue: 137/255)
//let kDayCircleColor = Color(red: 51/255, green: 197/255, blue: 88/255)
let kGradient1Color = Color(red: 3/255, green: 37/255, blue: 216/255)
let kGradient2Color = Color(red: 0/255, green: 140/255, blue: 149/255)
