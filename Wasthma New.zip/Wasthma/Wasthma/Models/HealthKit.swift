//
//  STM.swift
//  Wasthma
//
//  Created by Arma Qurrota Ayuni on 08/12/22.
//

import Foundation
import HealthKit

let store = HKHealthStore()

func requestPermission () async -> Bool {
    let write = Set([HKObjectType.workoutType(),
                        HKObjectType.quantityType(forIdentifier: .stepCount)!])
    let read = Set([HKCharacteristicType(.dateOfBirth),
                    HKCharacteristicType(.biologicalSex)])

    let res: ()? = try? await store.requestAuthorization(toShare: write, read: read)
    guard res != nil else {
        return false
    }

    return true
}
