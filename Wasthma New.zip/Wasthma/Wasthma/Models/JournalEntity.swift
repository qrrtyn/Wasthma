//
//  Journal.swift
//  Wasthma
//
//  Created by Arma Qurrota Ayuni on 05/12/22.
//

import Foundation

struct JournalEntity {
    var id = UUID()
    var feeling: String 
    var symptoms: String
    var triggers: String
    var medicines: String
    var notes: String
    var startTime: Date
    var endTime: Date
    var symptomsName: String
    var symptomsIsComplete: Bool
    var triggersName: String
    var triggersIsComplete: Bool
    var medicineName: String
    var medicineIsComplete: Bool
}
